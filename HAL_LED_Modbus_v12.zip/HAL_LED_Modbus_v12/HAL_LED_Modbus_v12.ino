// =============================================================================
// HAL_LED_Modbus_v12.ino  —  Final demo sketch
// LED blink control via Modbus TCP from RedLion Graphite GRAC0001
//
// LIBRARY REQUIRED:
//   ModbusEthernet by emelianov (search "Modbus-esp8266" in Library Manager)
//
// NETWORK:
//   Arduino:  192.168.1.100
//   Graphite: 192.168.1.20
//   PC:       192.168.1.10
//
// MODBUS REGISTER MAP:
//   Holding registers (Graphite WRITES — Crimson 4x):
//     400001 (index 0) — LED_ENABLE  : 0=off, 1=blink, 2=solid on
//     400002 (index 1) — BLINK_RATE  : tenths of Hz (10=1.0Hz, 25=2.5Hz)
//
//   Input registers (Graphite READS — Crimson 3x):
//     300001 (index 0) — LED_STATE   : current LED output (0 or 1)
//     300002 (index 1) — HEARTBEAT   : increments every second, rolls at 9999
// =============================================================================

#include <SPI.h>
#include <Ethernet.h>
#include <ModbusEthernet.h>

// ---------- Network ----------
byte      mac[]    = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0x01 };
IPAddress ip      (192, 168, 1, 100);
IPAddress gateway (192, 168, 1,   1);
IPAddress subnet  (255, 255, 255, 0);

ModbusEthernet mb;

// ---------- Pin ----------
#define LED_PIN 7

// ---------- Register indices (0-based) ----------
#define REG_LED_ENABLE  0   // Holding — 400001 in Crimson
#define REG_BLINK_RATE  1   // Holding — 400002 in Crimson
#define REG_LED_STATE   0   // Input   — 300001 in Crimson
#define REG_HEARTBEAT   1   // Input   — 300002 in Crimson

// ---------- State ----------
unsigned long lastBlink     = 0;
unsigned long lastHeartbeat = 0;
unsigned long lastDebug     = 0;
unsigned long blinkInterval = 500;
bool          ledState      = false;
int           heartbeat     = 0;

// =============================================================================
void setup() {
  Serial.begin(9600);
  delay(2000);
  Serial.println("Serial OK");

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Ethernet.begin(mac, ip);
  delay(2000);

  Serial.print("IP: ");
  Serial.println(Ethernet.localIP());

  mb.server();

  mb.addHreg(REG_LED_ENABLE, 1);   // default: blink
  mb.addHreg(REG_BLINK_RATE, 10);  // default: 1.0 Hz
  mb.addIreg(REG_LED_STATE,  0);
  mb.addIreg(REG_HEARTBEAT,  0);

  Serial.println("READY: Modbus TCP listening on port 502");
}

// =============================================================================
void loop() {
  mb.task();

  unsigned long now = millis();

  int enable    = mb.Hreg(REG_LED_ENABLE);
  int rateTenth = mb.Hreg(REG_BLINK_RATE);

  if (rateTenth > 0) {
    blinkInterval = 5000UL / rateTenth;
    if (blinkInterval < 50) blinkInterval = 50;
  }

  if (enable == 0) {
    ledState = false;
    digitalWrite(LED_PIN, LOW);
  } else if (enable == 2) {
    ledState = true;
    digitalWrite(LED_PIN, HIGH);
  } else {
    if (now - lastBlink >= blinkInterval) {
      lastBlink = now;
      ledState  = !ledState;
      digitalWrite(LED_PIN, ledState ? HIGH : LOW);
    }
  }

  mb.Ireg(REG_LED_STATE, ledState ? 1 : 0);

  if (now - lastHeartbeat >= 1000) {
    lastHeartbeat = now;
    heartbeat = (heartbeat + 1) % 10000;
    mb.Ireg(REG_HEARTBEAT, heartbeat);
  }

  // Single debug print every 5 seconds — keeps serial active
  // which stabilizes mb.task() timing on the W5100
  if (now - lastDebug >= 5000) {
    lastDebug = now;
    Serial.print("LED_Enable: "); Serial.println(enable);
    Serial.print("Blink_Rate: "); Serial.println(rateTenth);
    Serial.print("Heartbeat:  "); Serial.println(heartbeat);
  }
}
